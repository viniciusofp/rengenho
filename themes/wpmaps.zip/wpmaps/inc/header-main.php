<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<?php wp_head(); ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
<!-- 	<script
  src="https://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script> -->
  <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>


</head>
<body>