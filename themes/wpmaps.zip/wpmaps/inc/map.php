
	<div class="container-fluid">
		<div class="row">
			<div class="map-wrapper col-lg-12" style="padding: 0">
				
				<div class="filtre">
					<a href="#homecarousel" role="button" data-slide="next">
						<h6>Filtre sua busca</h6>
						<img src="<?php echo get_template_directory_uri(); ?>/img/filtre.png" alt="">
					</a>
				</div>
				<div id="map"></div>
			</div><!--  map-wrapper end -->
		</div>
	</div>