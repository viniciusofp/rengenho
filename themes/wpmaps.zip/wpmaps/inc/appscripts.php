<script async src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBpAdl_2nxCtwqL-3TC5STHHqGtF0QFTSQ&libraries=places"></script>
<script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/scripts.js"></script>

