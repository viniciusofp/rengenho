<?php get_header('dois'); ?>
<div class="archive-roteiro" ng-app="wpMap" ng-controller="Roteiro">
	<div class="container roteiro-menu">
		<div class="row">
			<div class="col-sm-12">
				<form>
				  <div class="row">
				    <div class="col-4">
				    	<label for="cidadeselect">Cidade</label>
				    	<div class="select-div">
				    		<i class="fas fa-angle-down select-caret"></i>
					      <select ng-change="changecity()" ng-model="cidadeFilter" name="cidade" id="cidadeselect" class="form-control">
					      	<option value="todas" selected>Todas</option>
					      	<option value="{{cidade.slug}}" ng-repeat="cidade in cidades" ng-bind-html="cidade.name"></option>
					      </select>
				    	</div>
				    </div>
				    <div class="col">
				    	<label for="deslocamentoslider">Deslocamento</label>
				      <rzslider id="deslocamentoslider" rz-slider-model="slider.minValue"
          rz-slider-high="slider.maxValue"
          rz-slider-options="slider.options"></rzslider>
				    </div>
				  </div>
				</form>
			</div>
		</div>
	</div>
	<div class=" container">
		<div class="row">

				<div ng-class="boxclass($index, post.cidadeInfo.slug)" ng-repeat="post in posts track by $index">
					<a href="{{post.link}}">
						<div class="box" style="background-image: url('{{post.img_large}}')">
							<div class="shadow">
								<div class="meta">
									<h2 class="title" ng-bind-html="post.title.rendered"></h2>
									<small ng-repeat="cidade in post.cidadeInfo">{{cidade.name}} <br></small>
									{{post.deslocamento}}km
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-12" ng-if="posts.length == 0">
					<h1>Não há roteiro para esses filtros.</h1>
				</div>

		</div>
	</div>
</div>

	
<?php include 'inc/appscripts.php' ?>
<?php get_footer(); ?>